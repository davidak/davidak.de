#!/usr/bin/perl
#
# Namen Generator
$version = "0.4";
#
# Creative Commons
# CC-BY-SA
#
# David Kleuker
# http://davidak.de/

use File::Slurp;

@vornamen_m = read_file('vornamen_m');
@vornamen_w = read_file('vornamen_w');
@nachnamen = read_file('nachnamen');

chomp (@vornamen_m, @vornamen_w, @nachnamen);

print "\nNamen Generator Version $version\n\n";

print "Anzahl: ";
chomp ($anzahl = <STDIN>);
print "\n";

print "Modus (0 gemischt, 1 männliche, 2 weibliche): ";
chomp ($modus = <STDIN>);
print "\n";

foreach $i (1..$anzahl) {

# Vorname
if ($modus == 0) {
$geschlecht = int(rand(2));
if ($geschlecht) { $name = $vornamen_m[rand(@vornamen_m)]; }
else { $name = $vornamen_w[rand(@vornamen_w)]; }
}

if ($modus == 1) { $name = $vornamen_m[rand(@vornamen_m)]; }
if ($modus == 2) { $name = $vornamen_w[rand(@vornamen_w)]; }

# Nachname
$name = $name.' '.$nachnamen[rand(@nachnamen)]."\n";

# Name ins Array
$data[$i] = $name;
}

write_file('namenliste.txt', @data);
print "\nDatei wurde erzeugt.\n\n";