<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 TRANSITIONAL//DE">
<html>

	<head>
		<title>Java Projects -> Projekte</title>
		<meta name="author" content="David Kleuker">
		<meta name="description" content="Java Projects ist ein Archiv von Java-Projekten, die ich im Laufe meines Java-Lernens programmieren werde.">
		<meta name="keywords" content="david, kleuker, java, code, source, sourcecode, programm, programmierung, davidak, archiv">
		<meta name="robots" content="all">

		<style type="text/css">

		body { margin-left:100px; margin-right:100px; margin-bottom:50px; marging-top:0px; background-color:#f58220; width:800px; }

		a:link { color:black; text-decoration: }
		a:visited { color:black; text-decoration:none; }
		a:focus { color:black; text-decoration:underline; }
		a:hover { color:white; text-decoration:none; }
		a:active { color:#f58220; text-decoration:underline; }

		</style>

	</head>
	<body>

	<img src="header.jpg" width:"800" height:"100" alt="Java Projects Header">


<p style="background-color:#4e7894; padding:2px; width:796px;"><a href="/index.php">Home</a> | <a href="/projekte.php">Projekte</a> | <a href="http://java.davidak.de/guestbook/gaestebuch.php">Kommentare zu den Programmen</a> | <a href="http://davidak.de/blog">Blog</a> | <a href="http://davidak.de/blog/?page_id=10">Impressum</a></p>


<table width="800" cellpadding="2" border="1" bgcolor="#328dca" bordercolor="#045184">
	<tr>
		<th align="center" style="background-color:#2b7cb2">Name</th>
		<th align="center" style="background-color:#2b7cb2">Beschreibung</th>
		<th align="center" style="background-color:#2b7cb2">Datum</th>
	</tr>
	<tr>
		<td align="center"><a href="projekt_testprojekt.php">Testprojekt</a></td>
		<td align="center">Dies ist kein richtiges Projekt. Es demonstriert nur das Layout der Projekt-Seite.</td>
		<td align="center">21.8.07</td>
	</tr>
</table>

<!-- Fuer ein neues Projekt einfach von <tr> bis </tr> kopieren. -->

<p align="right"; style="background-color:#4e7894; padding:2px; width:796px;">&copy; 2007 David Kleuker | <a href="http://www.davidak.de">davidak.de</a> | Version 0.4</p>

<p align="right"; style="background-color:#4e7894; padding:2px; width:796px;">Counter: <?php include("counter/txtcounter.php"); ?></p>

	</body>
</html>