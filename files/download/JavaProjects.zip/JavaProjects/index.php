<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 TRANSITIONAL//DE">
<html>

	<head>
		<title>Java Projects</title>
		<meta name="author" content="David Kleuker">
		<meta name="description" content="Java Projects ist ein Archiv von Java-Projekten, die ich im Laufe meines Java-Lernens programmieren werde.">
		<meta name="keywords" content="david, kleuker, java, code, source, sourcecode, programm, programmierung, davidak, archiv">
		<meta name="robots" content="all">

		<style type="text/css">

		body { margin-left:100px; margin-right:100px; margin-bottom:50px; marging-top:0px; background-color:#f58220; width:800px; }

		a:link { color:black; text-decoration: }
		a:visited { color:black; text-decoration:none; }
		a:focus { color:black; text-decoration:underline; }
		a:hover { color:white; text-decoration:none; }
		a:active { color:#f58220; text-decoration:underline; }

		</style>

	</head>
	<body>

	<img src="header.jpg" width:"800" height:"100" alt="Java Projects Header">


<p style="background-color:#4e7894; padding:2px; width:796px;"><a href="/index.php">Home</a> | <a href="/projekte.php">Projekte</a> | <a href="http://java.davidak.de/guestbook/gaestebuch.php">Kommentare zu den Programmen</a> | <a href="http://davidak.de/blog">Blog</a> | <a href="http://davidak.de/blog/?page_id=10">Impressum</a></p>


<p style="background-color:white; padding:2px; width:796px;">
Ich hab mich entschlossen, mal wieder mit Java anzufangen.<br>
Ich hatte vor 4 Jahren oder so ein Buch zur H&auml;lfte durchgearbeitet, aber weil es f&uuml;r "Studierende" war, ist es zu schwer geworden und ich hab nichts mehr verstanden.<br>
<br>
Jetzt, da ich &auml;lter geworden bin, werderde ich es nochmal versuchen.<br>
Aber, weil ich fast alles vergessen hab, lern ich es nochmal von Grund auf.<br>
<br>
Die Programme, die ich schreiben werde, will ich hier zum Download anbieten, damit vieleicht noch jemand was davon lernen kann oder inspiriert wird.<br>
Am Anfang sind es nur Spielereien mit dem neu Gelernten, aber sp&auml;ter, wenn ich schon Einiges kann, werden "richtige" Projekte folgen.<br>
<br>
<br>
Ich hatte erst vor, die Dateien mit einem CMS zu verwalten, aber da keines meinen Anspr&uuml;chen entsprach, hab ich in ein paar Abenden und N&auml;chten mit HTML und CSS diese Seiten geslatet.<br>
<br>
Erst hatte ich ein Design, mit blau-weissem Farbverlauf, danach ein gr&uuml;nes und als drittes eins, was zu Java passt.<br>
Also mit den Java-Farben (Orange und blau).<br>
<br>
Das wird erstmal das entg&uuml;ltige Design bleiben, nur an der Programmierung der Seite werde ich m&ouml;glicherweise noch &Auml;nderungen vornehmen.<br>
<br>
Aber ich will mehr Zeit ins Java-lernen investieren als ins rumbasteln an dieser Seite.<br>
</p>

<p align="right"; style="background-color:#4e7894; padding:2px; width:796px;">&copy; 2007 David Kleuker | <a href="http://www.davidak.de">davidak.de</a> | Version 0.4</p>

<p align="right"; style="background-color:#4e7894; padding:2px; width:796px;">Counter: <?php include("counter/txtcounter.php"); ?></p>

	</body>
</html>