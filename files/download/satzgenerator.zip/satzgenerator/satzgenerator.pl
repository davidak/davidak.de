#!/usr/bin/perl

####################
# Satzgenerator
$Version = 0.7;
#
# CC-BY-NC-SA
# 2010 David Kleuker
####################

use File::Slurp;
$i = 0;

# Daten einlesen
@vornamen = read_file('data/vornamen');
@verb = read_file('data/verb');
@verb2 = read_file('data/verb2');
@adj = read_file('data/adjektiv');
@ort = read_file('data/ort');

chomp (@vornamen, @verb, @verb2, @adj, @ort);

@beziehung_m = ('Vater', 'Bruder', 'Sohn', 'Onkel', 'Opa', 'Cousin', 'Enkel', 'Chef', 'Boss', 'Freund', 'Kumpel', 'Kollege', 'Mitarbeiter', 'Kamerad', 'Sklave', 'Partner', 'Mitbewohner', 'Vermieter', 'Lehrer');
@beziehung_w = ('Mutter', 'Schwester', 'Tochter', 'Tante', 'Oma', 'Cousine', 'Cheffin', 'Freundin', 'Partnerin', 'Mitbewohnerin', 'Vermieterin', 'Lehrerin');
@spezial = ('Er', 'Sie', 'Jemand', 'Irgendjemand', 'Niemand', 'Gott', 'Jesus', 'Der Papst', 'Der Reichskanzler', 'Der Bundeskanzler', 'Ein Held', 'Ein Penner', 'Ein Verkäufer', 'Ein Zuhälter', 'Eine Prostituierte', 'Eine Nutte', 'Eine Hure', 'Eine Schlampe', 'Ein Lehrer', 'Ein Polizist', 'Ein Beamter', 'Ein Arzt', 'Hitler', 'Ein Schwuler', 'Ein Behinderter', 'Die Sekretärin', 'Der Affenmensch', 'Die Transe', 'Das Mannsweib', 'Das Penismädchen', 'Die Lesbe', 'Die Kampflesbe', 'Der Satanist', 'Der Alkoholiker', 'Ein normaler Mensch');

# Angaben abfragen
print "\nSatzgenerator Version $Version von davidak\n\n";
print "Ausgabe in Konsole(0) oder Datei(1): ";
chomp ($modus = <STDIN>);
print "\nAnzahl: ";
chomp ($anzahl = <STDIN>);
print "\n";

# Satz generieren
while ($i<$anzahl){ $i++;
# Person
$z = int(rand(20));
if ($z == 1) { $person = $vornamen[rand(@vornamen)].'s '.$beziehung_m[rand(@beziehung_m)]; }
elsif ($z == 2) { $person = $vornamen[rand(@vornamen)].'s '.$beziehung_w[rand(@beziehung_w)]; }
elsif ($z == 4) { $person = 'Mein '.$beziehung_m[rand(@beziehung_m)]; }
elsif ($z == 5) { $person = 'Meine '.$beziehung_w[rand(@beziehung_w)]; }
elsif ($z == 6) { $person = 'Dein '.$beziehung_m[rand(@beziehung_m)]; }
elsif ($z == 7) { $person = 'Deine '.$beziehung_w[rand(@beziehung_w)]; }
elsif ($z == 8) { $person = 'Ihr '.$beziehung_m[rand(@beziehung_m)]; }
elsif ($z == 9) { $person = 'Ihre '.$beziehung_w[rand(@beziehung_w)]; }
elsif ($z == 10) { $person = 'Sein '.$beziehung_m[rand(@beziehung_m)]; }
elsif ($z == 11) { $person = 'Seine '.$beziehung_w[rand(@beziehung_w)]; }
elsif ($z == 12) { $person = $spezial[rand(@spezial)]; }
else { $person = $vornamen[rand(@vornamen)]; }
# Satz
$z = int(rand(3));
if ($z == 1) { ($v1, $v2) = split(/,/, $verb2[rand(@verb2)]); $satz = $person.' '.$v1.' '.$adj[rand(@adj)].' '.$ort[rand(@ort)].' '.$v2.'.'; }
else { $satz = $person.' '.$verb[rand(@verb)].' '.$adj[rand(@adj)].' '.$ort[rand(@ort)].'.'; }

# Ausgabe
if ($modus == 0) { print $i.'. '.$satz."\n"; }
if ($modus == 1) { $satze[$i] = $i.'. '.$satz."\n"; }
}
if ($modus == 1) { write_file('Saetze.txt', @satze); print "Datei wurde geschrieben.\n";}