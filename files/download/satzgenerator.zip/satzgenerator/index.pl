#!/usr/bin/perl
print "Content-type: text/html\n\n";
print "<!DOCTYPE html>\n";
print '<html lang="de">', "\n";
print "<head>\n";
print '<meta charset="utf-8" />', "\n";
print "<title>Satzgenerator</title>\n";
print '<link href="style.css" rel="stylesheet" media="screen" type="text/css" />', "\n";
print '<meta name="description" content="Mit dem Satzgenerator werden lustige Sätze generiert." />', "\n";
print '<meta name="keywords" content="Satz, Sätze, lustig, witzig, Fun, Spass, Fakten, Zufall" />', "\n";
print '<meta name="robots" content="index, follow" />', "\n";
print "</head>\n<body>\n";

####################
# Satzgenerator
# CC-BY-NC-SA
# 2010 David Kleuker
####################

use File::Slurp;
$i = 0;

# Daten einlesen
@vornamen = read_file('data/vornamen');
@verb = read_file('data/verb');
@verb2 = read_file('data/verb2');
@adj = read_file('data/adjektiv');
@ort = read_file('data/ort');

chomp (@vornamen, @verb, @verb2, @adj, @ort);

@beziehung_m = ('Vater', 'Bruder', 'Sohn', 'Onkel', 'Opa', 'Cousin', 'Enkel', 'Chef', 'Boss', 'Freund', 'Kumpel', 'Kollege', 'Mitarbeiter', 'Kamerad', 'Sklave', 'Partner', 'Mitbewohner', 'Vermieter', 'Lehrer');
@beziehung_w = ('Mutter', 'Schwester', 'Tochter', 'Tante', 'Oma', 'Cousine', 'Cheffin', 'Freundin', 'Partnerin', 'Mitbewohnerin', 'Vermieterin', 'Lehrerin');
@spezial = ('Er', 'Sie', 'Jemand', 'Irgendjemand', 'Niemand', 'Gott', 'Jesus', 'Der Papst', 'Der Reichskanzler', 'Der Bundeskanzler', 'Ein Held', 'Ein Penner', 'Ein Verkäufer', 'Ein Zuhälter', 'Eine Prostituierte', 'Eine Nutte', 'Eine Hure', 'Eine Schlampe', 'Ein Lehrer', 'Ein Polizist', 'Ein Beamter', 'Ein Arzt', 'Hitler', 'Ein Schwuler', 'Ein Behinderter', 'Die Sekretärin', 'Der Affenmensch', 'Die Transe', 'Das Mannsweib', 'Das Penismädchen', 'Die Lesbe', 'Die Kampflesbe', 'Der Satanist', 'Der Alkoholiker', 'Ein normaler Mensch');

# Satz generieren

# Person
$z = int(rand(20));

if ($z == 1) { $person = $vornamen[rand(@vornamen)].'s '.$beziehung_m[rand(@beziehung_m)]; }
elsif ($z == 2) { $person = $vornamen[rand(@vornamen)].'s '.$beziehung_w[rand(@beziehung_w)]; }
elsif ($z == 4) { $person = 'Mein '.$beziehung_m[rand(@beziehung_m)]; }
elsif ($z == 5) { $person = 'Meine '.$beziehung_w[rand(@beziehung_w)]; }
elsif ($z == 6) { $person = 'Dein '.$beziehung_m[rand(@beziehung_m)]; }
elsif ($z == 7) { $person = 'Deine '.$beziehung_w[rand(@beziehung_w)]; }
elsif ($z == 8) { $person = 'Ihr '.$beziehung_m[rand(@beziehung_m)]; }
elsif ($z == 9) { $person = 'Ihre '.$beziehung_w[rand(@beziehung_w)]; }
elsif ($z == 10) { $person = 'Sein '.$beziehung_m[rand(@beziehung_m)]; }
elsif ($z == 11) { $person = 'Seine '.$beziehung_w[rand(@beziehung_w)]; }
elsif ($z == 12) { $person = $spezial[rand(@spezial)]; }
else { $person = $vornamen[rand(@vornamen)]; }

$z = int(rand(3));
if ($z == 1) { ($v1, $v2) = split(/,/, $verb2[rand(@verb2)]); $satz = $person.' '.$v1.' '.$adj[rand(@adj)].' '.$ort[rand(@ort)].' '.$v2.'.'; }
else { $satz = $person.' '.$verb[rand(@verb)].' '.$adj[rand(@adj)].' '.$ort[rand(@ort)].'.'; }

print '<div id="tiny"><a href="http://davidak.de/wiki/perl/satzgenerator">http://davidak.de/wiki/perl/satzgenerator</a> CC-BY-NC-SA 2010 von davidak</div>', "\n";
print '<a href="javascript:location.reload()">';
print "<h1>$satz</h1></a>\n\n";

print <<ENDHTML;
<!-- Piwik -->
<script type="text/javascript">
var pkBaseURL = (("https:" == document.location.protocol) ? "https://davidak.de/stats/" : "http://davidak.de/stats/");
document.write(unescape("%3Cscript src='" + pkBaseURL + "piwik.js' type='text/javascript'%3E%3C/script%3E"));
</script><script type="text/javascript">
try {
var piwikTracker = Piwik.getTracker(pkBaseURL + "piwik.php", 1);
piwikTracker.trackPageView();
piwikTracker.enableLinkTracking();
} catch( err ) {}
</script><noscript><p><img src="http://davidak.de/stats/piwik.php?idsite=1" style="border:0" alt=""/></p></noscript>
<!-- End Piwik Tag -->
ENDHTML

print "\n</body>\n</html>\n";