#!/usr/bin/python
# -*- coding: utf-8 -*-
print 'Content-type: text/html\n'
print '<!DOCTYPE html>'
print '<html lang="de">'
print '<head>'
print '<meta charset="utf-8" />'
print '<title>Satzgenerator</title>'
print '<link href="style.css" rel="stylesheet" media="screen" type="text/css" />'
print '<meta name="description" content="Mit dem Satzgenerator werden lustige Sätze generiert." />'
print '<meta name="keywords" content="Satz, Sätze, Satzgenerator, Open Source, Python, lustig, witzig, Fun, Spass, Fakten, Zufall" />'
print '<meta name="robots" content="index, follow" />'
print '</head>\n<body>'

import random

# Daten aus Dateien einlesen
vornamen = open('data/vornamen', 'r').read().splitlines()
verb = open('data/verb', 'r').read().splitlines()
verb2 = open('data/verb2', 'r').read().splitlines()
adj = open('data/adjektiv', 'r').read().splitlines()
ort = open('data/ort', 'r').read().splitlines()

beziehung_m = ['Vater', 'Bruder', 'Mann', 'Sohn', 'Onkel', 'Opa', 'Cousin', 'Enkel', 'Chef', 'Freund', 'Partner', 'Kollege', 'Mitarbeiter', 'Mitbewohner', 'Vermieter', 'Lehrer']
beziehung_w = ['Mutter', 'Schwester', 'Frau', 'Tochter', 'Tante', 'Oma', 'Cousine', 'Enkelin', 'Cheffin', 'Freundin', 'Partnerin', 'Kollegin', 'Mitarbeiterin', 'Mitbewohnerin', 'Vermieterin', 'Lehrerin']
spezial = ['Er', 'Sie', 'Es', 'Jemand', 'Niemand', 'Ein Held', 'Ein Penner', 'Ein Verkäufer', 'Ein Zuhälter', 'Eine Prostituierte', 'Eine Nutte', 'Eine Hure', 'Eine Schlampe', 'Ein Lehrer', 'Ein Polizist', 'Ein Beamter', 'Ein Arzt', 'Hitler', 'Ein Bernd', 'Ein Schwuler', 'Ein Behinderter', 'Die Sekretärin', 'Der Affenmensch', 'Die Transe', 'Das Mannsweib', 'Das Penismädchen', 'Die Lesbe', 'Die Kampflesbe', 'Der Satanist', 'Der Alkoholiker', 'Ein normaler Mensch']
possessivpronomen_m = ['Mein', 'Dein', 'Sein', 'Ihr']

# Person generieren
z = random.randint(1,10)
if z == 1:
	person = random.choice(vornamen) + 's ' + random.choice(beziehung_m)
elif z == 2:
	person = random.choice(vornamen) + 's ' + random.choice(beziehung_w)
elif z == 3:
	person = random.choice(possessivpronomen_m) + ' ' + random.choice(beziehung_m)
elif z == 4:
	person = random.choice(possessivpronomen_m) + 'e ' + random.choice(beziehung_w)
elif z == 5:
	person = 'Der ' + random.choice(beziehung_m)
elif z == 6:
	person = 'Die ' + random.choice(beziehung_w)
elif z == 7:
	person = random.choice(spezial)
else:
	person = random.choice(vornamen)

# Satz generieren
z = random.randint(1,3)
if z == 2:
	v1, v2 = random.choice(verb2).split(",")
	satz = (person + ' ' + v1 + ' ' + random.choice(adj) + ' ' + random.choice(ort) + ' ' + v2 + '.')
else:
	satz = (person + ' ' + random.choice(verb) + ' ' + random.choice(adj) + ' ' + random.choice(ort) + '.')

print '<div id="tiny"><a href="http://davidak.de/wiki/python/satzgenerator">http://davidak.de/wiki/python/satzgenerator</a> CC-BY-NC-SA 2011 von davidak</div>'
print '<a href="javascript:location.reload()"><h1>' + satz + '</h1></a>\n'
print """<!-- Piwik -->
<script type="text/javascript">
var pkBaseURL = (("https:" == document.location.protocol) ? "https://davidak.de/stats/" : "http://davidak.de/stats/");
document.write(unescape("%3Cscript src='" + pkBaseURL + "piwik.js' type='text/javascript'%3E%3C/script%3E"));
</script><script type="text/javascript">
try {
var piwikTracker = Piwik.getTracker(pkBaseURL + "piwik.php", 1);
piwikTracker.trackPageView();
piwikTracker.enableLinkTracking();
} catch( err ) {}
</script><noscript><p><img src="http://davidak.de/stats/piwik.php?idsite=1" style="border:0" alt=""/></p></noscript>
<!-- End Piwik Tag -->"""
print '\n</body>\n</html>'